(() => {
  const FEED = window.BALLX_GRAPH && window.BALLX_GRAPH.endpoint;
  if (!FEED) return;

  async function init() {
    const container = document.getElementById("ballx-chart");
    if (!container) return;

    if (typeof window.LightweightCharts === "undefined") {
      console.error("BALLX: LightweightCharts não carregou.");
      return;
    }

    // garante altura
    container.style.minHeight = "300px";

    const w = container.clientWidth || container.offsetWidth || 600;

    const chart = LightweightCharts.createChart(container, {
      width: w,
      height: 300,
      layout: { background: { color: "transparent" }, textColor: "#FFFFFF" },
      grid: {
        vertLines: { color: "rgba(255,255,255,0.06)" },
        horzLines: { color: "rgba(255,255,255,0.06)" }
      },
      timeScale: { timeVisible: true, secondsVisible: false },
      rightPriceScale: { borderColor: "rgba(255,255,255,0.12)" }
    });

    // ✅ compatibilidade com versões diferentes do LightweightCharts
    let series = null;

    const areaOpts = {
      lineColor: "#2F7BFF",
      topColor: "rgba(47,123,255,0.35)",
      bottomColor: "rgba(47,123,255,0.02)",
      lineWidth: 2
    };

    if (typeof chart.addAreaSeries === "function") {
      series = chart.addAreaSeries(areaOpts);
    } else if (typeof chart.addSeries === "function" && LightweightCharts.AreaSeries) {
      series = chart.addSeries(LightweightCharts.AreaSeries, areaOpts);
    } else {
      console.error("BALLX: API do LightweightCharts incompatível (sem addAreaSeries/addSeries).", {
        hasAddAreaSeries: typeof chart.addAreaSeries,
        hasAddSeries: typeof chart.addSeries,
        AreaSeries: LightweightCharts.AreaSeries
      });
      return;
    }

    try {
      const res = await fetch(FEED, { cache: "no-store" });
      const json = await res.json();

      if (!json || !json.ok || !Array.isArray(json.candles)) {
        console.error("BALLX: JSON inválido do feed:", json);
        return;
      }

      const data = json.candles
        .map(c => ({ time: Number(c.time), value: Number(c.price) }))
        .filter(p => Number.isFinite(p.time) && Number.isFinite(p.value) && p.time > 0);

      if (!data.length) {
        console.error("BALLX: Sem dados válidos para plotar.");
        return;
      }

      data.sort((a, b) => a.time - b.time);

      series.setData(data);
      chart.timeScale().fitContent();
    } catch (e) {
      console.error("BALLX chart fetch error:", e);
    }

    window.addEventListener("resize", () => {
      const w2 = container.clientWidth || container.offsetWidth || 600;
      chart.applyOptions({ width: w2 });
    });
  }

  // roda mesmo se DOM já carregou
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // tentativa extra (Elementor render atrasado)
  setTimeout(() => {
    const c = document.getElementById("ballx-chart");
    if (!c) return;
    if (!c.querySelector("canvas")) init();
  }, 1200);
})();