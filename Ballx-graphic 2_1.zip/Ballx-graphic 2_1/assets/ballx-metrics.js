(() => {

  const FEED = window.BALLX_METRICS?.ticker;
  if (!FEED) return;

  function brl(v){
    if (!isFinite(v)) return "--";
    return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }

  function pct(v){
    if (!isFinite(v)) return "";
    return (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
  }

  async function load(){

    let data = null;

    try {
      const res = await fetch(FEED + "?symbol=BALLXBRL");
      data = await res.json();
    } catch(e){
      console.error("BALLX metrics error", e);
      return;
    }

    if (!data?.ok) return;

    const last = Number(data.last);
    const vol = Number(data.volume_24h_quote);
    const change = Number(data.change_pct_24h);
    const marketcap = last * 200000000000; // 200B supply total (ajustável)

    document.querySelectorAll(".ballx-metric").forEach(card => {

      const type = card.dataset.type;
      const manual = card.dataset.manual;
      const valueEl = card.querySelector(".ballx-metric__value");
      const changeEl = card.querySelector(".ballx-metric__change");

      if (manual) {
        valueEl.textContent = manual;
        changeEl.textContent = "";
        return;
      }

      switch(type){

        case "price":
          valueEl.textContent = brl(last);
          changeEl.textContent = pct(change);
          break;

        case "volume24h":
          valueEl.textContent = brl(vol);
          changeEl.textContent = pct(change);
          break;

        case "marketcap":
          valueEl.textContent = brl(marketcap);
          changeEl.textContent = "";
          break;

        case "supply":
          valueEl.textContent = "200B BALLX";
          changeEl.textContent = "";
          break;

        case "holders":
          valueEl.textContent = "Em breve";
          changeEl.textContent = "";
          break;
      }

    });
  }

  document.addEventListener("DOMContentLoaded", load);
  setInterval(load, 30000);

})();