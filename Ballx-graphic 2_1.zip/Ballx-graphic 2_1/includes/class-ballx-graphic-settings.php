<?php
namespace BALLX_Graphic;

if (!defined('ABSPATH')) { exit; }

class Settings {
    const OPT_GROUP = 'ballx_graphic_group';
    const OPT_NAME  = 'ballx_graphic_settings';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'register']);
    }

    public static function get(): array {
        $defaults = [
            'polygonscan_api_key' => '',
            'rpc_url'             => '', // para futuro (leitura direta por RPC)
            'contract'            => '0xa0d5de9cea5bfd3ae15408bbb69ad54764d66140',
            'topic0'              => '0xd6938ef0263731afa1121cc53043409ea7fe90723ae457040dba44c6269bab6f',
            'token_decimals'      => 18,
            'brl_scale'           => 100,
            'cache_seconds'       => 60,
        ];

        $saved = get_option(self::OPT_NAME, []);
        if (!is_array($saved)) $saved = [];

        return array_merge($defaults, $saved);
    }

    public static function menu() {
        add_options_page(
            'BALLX Graphic',
            'BALLX Graphic',
            'manage_options',
            'ballx-graphic',
            [__CLASS__, 'page']
        );
    }

    public static function register() {
        register_setting(self::OPT_GROUP, self::OPT_NAME, [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize'],
            'default' => [],
        ]);
    }

    public static function sanitize($input) {
        $out = self::get();

        $out['polygonscan_api_key'] = sanitize_text_field((string)($input['polygonscan_api_key'] ?? ''));
        $out['rpc_url']             = esc_url_raw((string)($input['rpc_url'] ?? ''));

        $out['contract'] = strtolower(sanitize_text_field((string)($input['contract'] ?? $out['contract'])));
        $out['topic0']   = strtolower(sanitize_text_field((string)($input['topic0'] ?? $out['topic0'])));

        $out['token_decimals'] = max(0, (int)($input['token_decimals'] ?? $out['token_decimals']));
        $out['brl_scale']      = max(1, (int)($input['brl_scale'] ?? $out['brl_scale']));
        $out['cache_seconds']  = max(5, (int)($input['cache_seconds'] ?? $out['cache_seconds']));

        return $out;
    }

    public static function page() {
        if (!current_user_can('manage_options')) return;

        $s = self::get();
        ?>
        <div class="wrap">
            <h1>BALLX Graphic</h1>
            <form method="post" action="options.php">
                <?php settings_fields(self::OPT_GROUP); ?>
                <table class="form-table" role="presentation">

                    <tr>
                        <th scope="row">PolygonScan API Key</th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_NAME); ?>[polygonscan_api_key]"
                                   value="<?php echo esc_attr($s['polygonscan_api_key']); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">RPC URL (futuro)</th>
                        <td>
                            <input type="url" class="regular-text" name="<?php echo esc_attr(self::OPT_NAME); ?>[rpc_url]"
                                   value="<?php echo esc_attr($s['rpc_url']); ?>" placeholder="https://polygon-rpc.com (ou seu RPC pago)" />
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Contract</th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_NAME); ?>[contract]"
                                   value="<?php echo esc_attr($s['contract']); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Topic0</th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_NAME); ?>[topic0]"
                                   value="<?php echo esc_attr($s['topic0']); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Cache (segundos)</th>
                        <td>
                            <input type="number" min="5" step="1" name="<?php echo esc_attr(self::OPT_NAME); ?>[cache_seconds]"
                                   value="<?php echo esc_attr($s['cache_seconds']); ?>" />
                        </td>
                    </tr>

                </table>
                <?php submit_button('Salvar'); ?>
            </form>

            <hr>
            <p><b>Teste do endpoint:</b> <code>/wp-json/ballx/v1/chart</code></p>
        </div>
        <?php
    }
}