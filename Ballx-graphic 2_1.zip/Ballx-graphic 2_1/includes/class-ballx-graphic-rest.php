<?php
namespace BALLX_Graphic;

if (!defined('ABSPATH')) { exit; }

class Rest {

    const CACHE_KEY_CHART = 'ballx_chart_cache_v1';

    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    public static function routes() {

        register_rest_route('ballx/v1', '/chart', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'chart'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ballx/v1', '/exchange/pairs', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'exchange_pairs'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ballx/v1', '/exchange/ticker', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'exchange_ticker'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ballx/v1', '/exchange/summary', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'exchange_summary'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ballx/v1', '/exchange/trades', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'exchange_trades'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ballx/v1', '/exchange/orderbook', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'exchange_orderbook'],
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * ✅ Chart baseline (corrigido p/ Etherscan API V2)
     *
     * Ajustes finos PROFISSIONAIS:
     * - Corrige "explosão" de preço quando amountBallx vem como "unidade humana" (ex: 1 = 1 BALLX)
     * - Aceita também amountBallx em "wei" (18 decimais) automaticamente (ex: 1e18 = 1 BALLX)
     * - Evita volume virar 0 por arredondamento agressivo
     * - last_price pega o último candle ordenado
     */
    public static function chart(\WP_REST_Request $req) {
        $s = Settings::get();

        $apikey  = trim((string)($s['polygonscan_api_key'] ?? '')); // mantém o nome do campo pra não quebrar Settings
        $address = trim((string)($s['contract'] ?? ''));
        $topic0  = trim((string)($s['topic0'] ?? ''));

        if ($apikey === '' || $address === '' || $topic0 === '') {
            return rest_ensure_response([
                'ok' => false,
                'error' => 'Config incompleta: API key/contract/topic0',
            ]);
        }

        // cache por contrato+topic (pra não misturar)
        $cacheKey = self::CACHE_KEY_CHART . '_' . strtolower($address) . '_' . strtolower($topic0);
        $cached = get_transient($cacheKey);
        if ($cached) {
            return rest_ensure_response($cached);
        }

        /**
         * ✅ Etherscan API V2 (Polygon via chainid=137)
         */
        $url = add_query_arg([
            'chainid'  => '137',     // Polygon
            'module'   => 'logs',
            'action'   => 'getLogs',
            'fromBlock'=> '1',
            'toBlock'  => 'latest',
            'address'  => $address,
            'topic0'   => $topic0,
            'apikey'   => $apikey,
        ], 'https://api.etherscan.io/v2/api');

        $resp = wp_remote_get($url, ['timeout' => 20]);
        if (is_wp_error($resp)) {
            return rest_ensure_response(['ok' => false, 'error' => $resp->get_error_message(), 'url' => $url]);
        }

        $body = wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);

        if (!is_array($data)) {
            return rest_ensure_response([
                'ok' => false,
                'error' => 'JSON inválido da API',
                'raw' => $body,
                'url' => $url,
            ]);
        }

        if (($data['status'] ?? '') !== '1') {
            return rest_ensure_response([
                'ok' => false,
                'error' => 'API NOTOK',
                'message' => $data['message'] ?? null,
                'result'  => $data['result'] ?? null,
                'url' => $url,
            ]);
        }

        $candles = [];
        $result = $data['result'] ?? [];
        if (!is_array($result)) $result = [];

        // Settings (baseline)
        // ✅ mantenha 18 no admin (padrão do token). Aqui a gente auto-detecta humano vs wei.
        $decimals_cfg = (int)($s['token_decimals'] ?? 18);
        $brlScale     = (int)($s['brl_scale'] ?? 100);     // 100 => centavos -> reais

        foreach ($result as $log) {

            $tsHex = (string)($log['timeStamp'] ?? '');
            $ts = self::hexdec_safe($tsHex);
            if ($ts <= 0) continue;

            $raw = (string)($log['data'] ?? '');
            if (strpos($raw, '0x') !== 0) continue;

            $clean = substr($raw, 2);

            /**
             * TradeRecorded non-indexed (data):
             * [0] amountBallx
             * [1] brlValueCents
             * [2] authorized
             * [3] offset_reason
             * [4] refHash
             */
            if (strlen($clean) < 64 * 5) continue;

            $w0 = substr($clean, 0, 64);      // amountBallx
            $w1 = substr($clean, 64, 64);     // brlValueCents

            $amountRaw = self::hex_to_number($w0);
            $brlRaw    = self::hex_to_number($w1);

            if ($amountRaw === null || $brlRaw === null) {
                continue; // número grande demais sem GMP
            }

            // ---- Converte BRL (centavos) -> reais
            $brlCents = self::number_to_float($brlRaw, 0);
            if ($brlCents <= 0) continue;

            $brlValue = $brlCents / max(1, $brlScale);
            if ($brlValue <= 0) continue;

            /**
             * ✅ amountBallx robusto:
             * - BALLX Store envia "unidade humana" (1, 5, 10, 50000...) => decimals 0
             * - Exchanges podem enviar "wei" (18 decimais)             => decimals 18
             *
             * Regra por magnitude (não quebra e não depende de float pequeno):
             * - Se vier GIGANTE (>= 1e12 ou string com muitos dígitos), tratamos como wei.
             * - Se vier pequeno, tratamos como unidade humana.
             */
            $amount = 0.0;

            if (is_object($amountRaw) && function_exists('gmp_strval')) {
                $rawStr = gmp_strval($amountRaw, 10);

                // 1 BALLX em wei = 1000000000000000000 (19 dígitos)
                // então >= 18 dígitos já é forte sinal de wei
                $isWei = (strlen($rawStr) >= 18);

                $amount = $isWei
                    ? self::number_to_float($amountRaw, max(0, $decimals_cfg)) // normalmente 18
                    : self::number_to_float($amountRaw, 0);
            } else {
                $rawF = (float)$amountRaw;

                // threshold bem seguro: humano na loja nunca chega perto disso
                $isWei = ($rawF >= 1000000000000.0); // 1e12

                $amount = $isWei
                    ? self::number_to_float($amountRaw, max(0, $decimals_cfg)) // normalmente 18
                    : self::number_to_float($amountRaw, 0);
            }

            if ($amount <= 0) continue;

            // preço final
            $price = $brlValue / $amount;

            // proteção anti-lixo: se ainda explodir, ignora (evita poluir gráfico/feeds)
            if (!is_finite($price) || $price <= 0) continue;
            if ($price > 1000000000) continue; // > 1 bi BRL por BALLX => certamente escala errada / teste ruim

            // ✅ volume: não arredonda agressivo para não virar 0
            $candles[] = [
                'time'   => (int)$ts,
                'price'  => (float)round($price, 8),
                'volume' => (float)round($amount, 12),
            ];
        }

        usort($candles, fn($a,$b) => $a['time'] <=> $b['time']);

        $last = null;
        if (!empty($candles)) {
            $last = (float)($candles[count($candles)-1]['price'] ?? null);
        }

        $out = [
            'ok' => true,
            'symbol' => 'BALLX/BRL',
            'currency' => 'BRL',
            'last_price' => $last !== null ? (float)round($last, 8) : null,
            'timestamp' => time(),
            'count' => count($candles),
            'candles' => $candles,
            'logs_total' => count($result),
        ];

        $cache_seconds = max(5, (int)($s['cache_seconds'] ?? 30));
        set_transient($cacheKey, $out, $cache_seconds);

        return rest_ensure_response($out);
    }

    public static function exchange_pairs(\WP_REST_Request $req) {
        return rest_ensure_response([
            'ok' => true,
            'exchange' => 'BALLX',
            'pairs' => [
                [
                    'symbol' => 'BALLXBRL',
                    'base'   => 'BALLX',
                    'quote'  => 'BRL',
                    'status' => 'active',
                ],
            ],
            'timestamp' => time(),
        ]);
    }

    /**
     * ✅ Ticker profissional:
     * - last / high_24h / low_24h
     * - volume_24h_base (BALLX)
     * - volume_24h_quote (BRL)  <= throughput em reais (o que você chama de "Economic Throughput")
     * - vwap_24h (preço médio ponderado por volume)
     * - change_24h / change_pct_24h (comparando primeiro vs último dentro da janela)
     */
    public static function exchange_ticker(\WP_REST_Request $req) {
        $symbol = strtoupper((string)$req->get_param('symbol'));
        if ($symbol === '') $symbol = 'BALLXBRL';

        if ($symbol !== 'BALLXBRL') {
            return rest_ensure_response(['ok' => false, 'error' => 'symbol not supported']);
        }

        $chart = self::get_chart_cached();
        if (empty($chart['ok'])) {
            return rest_ensure_response(['ok' => false, 'error' => 'chart not available']);
        }

        $candles = $chart['candles'] ?? [];
        $last    = $chart['last_price'] ?? null;

        $now = time();
        $cut = $now - 86400;

        $prices_24h = [];
        $volume_base_24h  = 0.0;
        $volume_quote_24h = 0.0; // BRL
        $first_price_24h  = null;
        $last_price_24h   = null;

        if (is_array($candles)) {
            foreach ($candles as $c) {
                if (!isset($c['time'], $c['price'])) continue;
                if ((int)$c['time'] < $cut) continue;

                $p = (float)$c['price'];
                $v = (float)($c['volume'] ?? 0);

                $prices_24h[] = $p;

                $volume_base_24h  += $v;
                $volume_quote_24h += ($p * $v);

                if ($first_price_24h === null) $first_price_24h = $p;
                $last_price_24h = $p;
            }
        }

        $high24 = !empty($prices_24h) ? max($prices_24h) : null;
        $low24  = !empty($prices_24h) ? min($prices_24h) : null;

        // variação 24h (primeiro -> último dentro da janela)
        $change24 = null;
        $changePct24 = null;
        if ($first_price_24h !== null && $last_price_24h !== null && $first_price_24h > 0) {
            $change24 = $last_price_24h - $first_price_24h;
            $changePct24 = ($change24 / $first_price_24h) * 100;
        }

        // VWAP (preço médio ponderado por volume em 24h)
        $vwap24 = null;
        if ($volume_base_24h > 0) {
            $vwap24 = $volume_quote_24h / $volume_base_24h;
        }

        return rest_ensure_response([
            'ok' => true,
            'symbol' => 'BALLXBRL',
            'base'   => 'BALLX',
            'quote'  => 'BRL',

            'last'   => $last !== null ? (float)$last : null,
            'high_24h' => $high24 !== null ? (float)round($high24, 8) : null,
            'low_24h'  => $low24  !== null ? (float)round($low24, 8)  : null,

            'volume_24h_base'  => (float)round($volume_base_24h, 12),   // BALLX
            'volume_24h_quote' => (float)round($volume_quote_24h, 2),    // BRL (Economic Throughput)
            'vwap_24h'         => $vwap24 !== null ? (float)round($vwap24, 8) : null,

            'change_24h'       => $change24 !== null ? (float)round($change24, 8) : null,
            'change_pct_24h'   => $changePct24 !== null ? (float)round($changePct24, 4) : null,

            'timestamp' => $now,
            'source' => 'ballx_chart',
        ]);
    }

    public static function exchange_summary(\WP_REST_Request $req) {
        return rest_ensure_response([
            'ok' => true,
            'exchange' => 'BALLX',
            'markets' => [
                [
                    'symbol' => 'BALLXBRL',
                    'base'   => 'BALLX',
                    'quote'  => 'BRL',
                    'status' => 'active',
                ],
            ],
            'timestamp' => time(),
        ]);
    }

    public static function exchange_trades(\WP_REST_Request $req) {
        $symbol = strtoupper((string)$req->get_param('symbol'));
        if ($symbol === '') $symbol = 'BALLXBRL';

        if ($symbol !== 'BALLXBRL') {
            return rest_ensure_response(['ok' => false, 'error' => 'symbol not supported']);
        }

        $limit = (int)$req->get_param('limit');
        if ($limit <= 0) $limit = 50;
        $limit = min(200, $limit);

        $chart = self::get_chart_cached();
        if (empty($chart['ok'])) {
            return rest_ensure_response(['ok' => false, 'error' => 'chart not available']);
        }

        $candles = $chart['candles'] ?? [];
        if (!is_array($candles)) $candles = [];

        $slice = array_slice($candles, -$limit);

        $trades = [];
        foreach ($slice as $c) {
            if (!isset($c['time'], $c['price'])) continue;

            $trades[] = [
                'trade_id' => (string)($c['time'] . '-' . $c['price']),
                'symbol'   => 'BALLXBRL',
                'price'    => (float)$c['price'],
                'amount'   => (float)($c['volume'] ?? 0),
                'side'     => 'buy',
                'timestamp'=> (int)$c['time'],
            ];
        }

        return rest_ensure_response([
            'ok' => true,
            'symbol' => 'BALLXBRL',
            'count'  => count($trades),
            'trades' => $trades,
            'timestamp' => time(),
            'source' => 'ballx_chart',
        ]);
    }

    public static function exchange_orderbook(\WP_REST_Request $req) {
        $symbol = strtoupper((string)$req->get_param('symbol'));
        if ($symbol === '') $symbol = 'BALLXBRL';

        if ($symbol !== 'BALLXBRL') {
            return rest_ensure_response(['ok' => false, 'error' => 'symbol not supported']);
        }

        return rest_ensure_response([
            'ok' => true,
            'symbol' => 'BALLXBRL',
            'bids' => [],
            'asks' => [],
            'timestamp' => time(),
            'note' => 'BALLX não possui book; este endpoint é apenas compatibilidade.',
        ]);
    }

    private static function get_chart_cached(): array {
        $resp = self::chart(new \WP_REST_Request('GET', '/ballx/v1/chart'));
        $data = $resp instanceof \WP_REST_Response ? $resp->get_data() : (array)$resp;
        return is_array($data) ? $data : ['ok' => false];
    }

    /**
     * ✅ conversão segura de hex -> int (64-bit) ou GMP (se existir)
     * retorna null se não dá pra converter com segurança
     */
    private static function hex_to_number(string $hex) {
        $hex = strtolower(trim($hex));
        $hex = ltrim($hex, '0');

        if ($hex === '') return 0;

        // 64-bit = até 16 hex
        if (strlen($hex) <= 16) {
            return hexdec($hex);
        }

        if (function_exists('gmp_init')) {
            return gmp_init($hex, 16);
        }

        return null;
    }

    /**
     * ✅ number (int|float|GMP) -> float com decimais
     */
    private static function number_to_float($n, int $decimals = 0): float {
        if (is_int($n) || is_float($n)) {
            if ($decimals <= 0) return (float)$n;
            return (float)$n / (10 ** $decimals);
        }

        if (is_object($n) && function_exists('gmp_strval')) {
            if ($decimals <= 0) return (float)gmp_strval($n, 10);
            return self::gmp_div_to_float($n, $decimals);
        }

        return 0.0;
    }

    /**
     * ✅ timeStamp hex ("0x..") -> int
     */
    private static function hexdec_safe(string $hex): int {
        $hex = trim($hex);
        if ($hex === '') return 0;
        if (strpos($hex, '0x') === 0 || strpos($hex, '0X') === 0) {
            $hex = substr($hex, 2);
        }
        $hex = ltrim(strtolower($hex), '0');
        if ($hex === '') return 0;

        if (strlen($hex) <= 16) return (int)hexdec($hex);

        if (function_exists('gmp_init')) {
            return (int)gmp_strval(gmp_init($hex, 16), 10);
        }

        return 0;
    }

    private static function gmp_div_to_float($gmpInt, int $decimals): float {
        $str = gmp_strval($gmpInt, 10);
        if ($decimals <= 0) return (float)$str;

        $len = strlen($str);
        if ($len <= $decimals) {
            $str = str_pad($str, $decimals + 1, '0', STR_PAD_LEFT);
            $len = strlen($str);
        }

        $intPart  = substr($str, 0, $len - $decimals);
        $fracPart = substr($str, $len - $decimals);

        $fracPart = substr($fracPart, 0, 12);
        return (float)($intPart . '.' . $fracPart);
    }
}
