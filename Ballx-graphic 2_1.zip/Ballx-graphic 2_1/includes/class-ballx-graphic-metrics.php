<?php
namespace BALLX_Graphic;

if (!defined('ABSPATH')) { exit; }

class Metrics {

    public static function init() {
        add_shortcode('ballx_metric', [__CLASS__, 'render']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'register_assets']);
    }

    public static function register_assets() {

        wp_register_script(
            'ballx-metrics',
            BALLX_GRAPHIC_URL . 'assets/ballx-metrics.js',
            [],
            time(),
            true
        );

        wp_localize_script('ballx-metrics', 'BALLX_METRICS', [
            'ticker' => esc_url_raw(rest_url('ballx/v1/exchange/ticker')),
        ]);
    }

    public static function render($atts) {

        $atts = shortcode_atts([
            'type'  => 'price',
            'title' => '',
            'manual' => '' // para supply/holders se quiser manual
        ], $atts);

        wp_enqueue_script('ballx-metrics');

        return '
        <div class="ballx-metric" 
             data-type="' . esc_attr($atts['type']) . '" 
             data-manual="' . esc_attr($atts['manual']) . '">

            <div class="ballx-metric__title">' . esc_html($atts['title']) . '</div>
            <div class="ballx-metric__value">--</div>
            <div class="ballx-metric__change"></div>
        </div>';
    }
}