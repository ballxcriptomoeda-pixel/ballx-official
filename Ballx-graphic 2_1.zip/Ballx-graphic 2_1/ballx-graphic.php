<?php
/**
 * Plugin Name: BALLX Graphic
 * Description: Gráfico e endpoints REST para BALLX.
 * Version: 2.2.0
 */

namespace BALLX_Graphic;

if (!defined('ABSPATH')) { exit; }

define('BALLX_GRAPHIC_VERSION', '1.1.0');
define('BALLX_GRAPHIC_PATH', plugin_dir_path(__FILE__));
define('BALLX_GRAPHIC_URL', plugin_dir_url(__FILE__));

// ✅ includes
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-settings.php';
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-rest.php';
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-shortcode.php';

// 🔹 NOVO include (metrics)
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-metrics.php';

// ✅ init
add_action('plugins_loaded', function () {

    if (class_exists('\\BALLX_Graphic\\Settings'))  { Settings::init(); }
    if (class_exists('\\BALLX_Graphic\\Rest'))      { Rest::init(); }
    if (class_exists('\\BALLX_Graphic\\Shortcode')) { Shortcode::init(); }

    // 🔹 NOVO init metrics
    if (class_exists('\\BALLX_Graphic\\Metrics'))   { Metrics::init(); }
});