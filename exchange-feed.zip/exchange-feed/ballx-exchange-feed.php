<?php
header("Content-Type: application/json");

$RPC = "https://polygon-rpc.com";

$CONTRACT = "0xa0d5de9cea5bfd3ae15408bbb69ad54764d66140";
$TOPIC0   = "0xd6938ef0263731afa1121cc53043409ea7fe90723ae457040dba44c6269bab6f";

/**
 * ===============================
 * SCALE (FINAL E CORRETO)
 * ===============================
 * Evento grava BRL em CENTAVOS
 */
$BRL_SCALE      = 100;
$TOKEN_DECIMALS = 18;

function pow10($n) {
    return pow(10, $n);
}

function hexToDecString($hex) {
    $hex = ltrim($hex, "0");
    if ($hex === "") return "0";
    if (function_exists("gmp_init")) {
        return gmp_strval(gmp_init($hex, 16), 10);
    }
    return (string) hexdec($hex);
}

function decStringToFloat($decStr) {
    return (float) $decStr;
}

/* ===============================
   BUSCA LOGS
   =============================== */
$payload = [
    "jsonrpc" => "2.0",
    "id" => 1,
    "method" => "eth_getLogs",
    "params" => [[
        "fromBlock" => "0x0",
        "toBlock"   => "latest",
        "address"   => $CONTRACT,
        "topics"    => [$TOPIC0]
    ]]
];

$context = stream_context_create([
    "http" => [
        "method"  => "POST",
        "header"  => "Content-Type: application/json",
        "content" => json_encode($payload)
    ]
]);

$response = file_get_contents($RPC, false, $context);
$data = json_decode($response, true);

$candles = [];
$last_order = null;
$last_price_raw = null;

if (!empty($data["result"])) {
    foreach ($data["result"] as $log) {

        // timestamp
        $blockHex = $log["blockNumber"];

        $blockPayload = [
            "jsonrpc" => "2.0",
            "id" => 1,
            "method" => "eth_getBlockByNumber",
            "params" => [$blockHex, false]
        ];

        $blockRes = json_decode(
            file_get_contents($RPC, false, $context),
            true
        );

        if (!isset($blockRes["result"]["timestamp"])) continue;
        $time = hexdec($blockRes["result"]["timestamp"]);

        // data do evento
        $raw = str_replace("0x", "", $log["data"]);

        $amountHex = substr($raw, 0, 64);
        $brlHex    = substr($raw, 64, 64);

        $amountRaw = decStringToFloat(hexToDecString($amountHex));
        $brlRaw    = decStringToFloat(hexToDecString($brlHex));

        $amount = $amountRaw / pow10($TOKEN_DECIMALS);
        $brl    = $brlRaw / $BRL_SCALE;

        if ($amount <= 0 || $brl <= 0) continue;

        $price_raw = $brl / $amount;
        $last_price_raw = $price_raw;

        // ORDER (assinatura BALLX)
        if (isset($log["data"]) && strlen($raw) > 128) {
            $orderText = hex2bin(substr($raw, 128));
            $last_order = trim($orderText);
        }

        $candles[] = [
            "time"   => $time,
            "price"  => round($price_raw, 8),
            "volume" => round($amount, 6)
        ];
    }
}

usort($candles, fn($a, $b) => $a["time"] <=> $b["time"]);

/* ===============================
   JSON FINAL PROFISSIONAL
   =============================== */
echo json_encode([
    "symbol"      => "BALLX/BRL",
    "currency"    => "BRL",
    "tick_size"   => 0.01,

    "last_price"  => round($last_price_raw, 2),
    "price_raw"   => round($last_price_raw, 8),

    "timestamp"   => time(),
    "last_order"  => $last_order,

    "candles"     => $candles
]);