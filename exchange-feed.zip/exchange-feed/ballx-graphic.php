<?php
/*
Plugin Name: BALLX Graph Shortcode
Description: Exibe o gráfico BALLX via shortcode [ballx_graph]
Version: 1.2
*/

if (!defined('ABSPATH')) exit;

/**
 * 1) CARREGA OS SCRIPTS DO GRÁFICO
 */
function ballx_graph_assets() {

    wp_enqueue_script(
        'lightweight-charts',
        'https://unpkg.com/lightweight-charts/dist/lightweight-charts.standalone.production.js',
        [],
        null,
        true
    );

    wp_enqueue_script(
        'ballx-chart',
        plugins_url('assets/ballx-chart-item1.js', __FILE__),
        ['lightweight-charts'],
        time(),
        true
    );

    wp_localize_script('ballx-chart', 'BALLX_API', [
        'endpoint' => rest_url('ballx/v1/exchange-feed')
    ]);
}
add_action('wp_enqueue_scripts', 'ballx_graph_assets');


/**
 * 2) SHORTCODE
 */
function ballx_graph_shortcode() {
    return '
        <div id="ballx-chart" style="
            width:100%;
            height:300px;
            margin:0 auto;
            position:relative;
            z-index:10;
        "></div>
    ';
}
add_shortcode('ballx_graph', 'ballx_graph_shortcode');


/**
 * 3) ENDPOINT REST
 */
add_action('rest_api_init', function () {

    register_rest_route('ballx/v1', '/exchange-feed', [
        'methods'  => 'GET',
        'callback' => 'ballx_exchange_feed_endpoint',
        'permission_callback' => '__return_true'
    ]);

});


/**
 * 4) CALLBACK — OPÇÃO A (TESTE FORÇADO)
 */
function ballx_exchange_feed_endpoint() {

    header('Content-Type: application/json');

    echo json_encode([
        "candles" => [
            [
                "time"  => time() - 3600,
                "price" => 1.23
            ],
            [
                "time"  => time() - 1800,
                "price" => 1.31
            ],
            [
                "time"  => time(),
                "price" => 1.38
            ]
        ]
    ]);

    exit;
}