<?php
namespace BALLX_Graphic;

if (!defined('ABSPATH')) { exit; }

class Shortcode {

    public static function init() {
        add_shortcode('ballx_graph', [__CLASS__, 'render']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'register_assets']);
    }

    public static function register_assets() {

        // ✅ FIXA versão que possui addAreaSeries (v4.x)
        wp_register_script(
            'lightweight-charts',
            'https://unpkg.com/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js',
            [],
            '4.2.0',
            true
        );

        // ✅ cache-bust temporário (depois você volta pro BALLX_GRAPHIC_VERSION)
        wp_register_script(
            'ballx-graph',
            BALLX_GRAPHIC_URL . 'assets/ballx-graph.js',
            ['lightweight-charts'],
            time(),
            true
        );

        wp_localize_script('ballx-graph', 'BALLX_GRAPH', [
            'endpoint' => esc_url_raw(rest_url('ballx/v1/chart')),
        ]);
    }

    public static function render() {
        wp_enqueue_script('lightweight-charts');
        wp_enqueue_script('ballx-graph');

        // ✅ container com min-height pra evitar width/height 0 em render atrasado (Elementor)
        return '<div id="ballx-chart" style="width:100%;min-height:300px;height:300px;position:relative;"></div>';
    }
}