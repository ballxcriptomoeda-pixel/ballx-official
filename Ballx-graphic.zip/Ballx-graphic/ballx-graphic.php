<?php
/**
 * Plugin Name: BALLX Graphic
 * Description: Gráfico e endpoints REST para BALLX.
 * Version: 1.1.0 - ultima atualização: 20\02\2026
 */

namespace BALLX_Graphic;

if (!defined('ABSPATH')) { exit; }

define('BALLX_GRAPHIC_VERSION', '1.1.0');
define('BALLX_GRAPHIC_PATH', plugin_dir_path(__FILE__));
define('BALLX_GRAPHIC_URL', plugin_dir_url(__FILE__));

// ✅ includes (bate com os nomes da sua pasta)
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-settings.php';
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-rest.php';
require_once BALLX_GRAPHIC_PATH . 'includes/class-ballx-graphic-shortcode.php';

// ✅ init
add_action('plugins_loaded', function () {
    if (class_exists('\\BALLX_Graphic\\Settings'))  { Settings::init(); }
    if (class_exists('\\BALLX_Graphic\\Rest'))      { Rest::init(); }
    if (class_exists('\\BALLX_Graphic\\Shortcode')) { Shortcode::init(); }
});